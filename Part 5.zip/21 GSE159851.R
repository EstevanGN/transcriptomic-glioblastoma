# ##################################################################### # 
# --------------------------------------------------------------------- #
# Carga de datos ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- read.csv("22 GSE159851_Schaffenrath_RNAseq_GBM_BM_control.csv",
               header=T)
dim(ex) # 21908 18
colnames(ex)[1] <- "ENSEMBL"

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Simbolo de gen ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
keytypes(org.Hs.eg.db)
cols <- c("SYMBOL")
ensids <- ex$ENSEMBL
anot <- select(org.Hs.eg.db, keys=ensids, columns=cols, keytype="ENSEMBL")

dim(anot) # 22068 2
length(unique(anot$ENSEMBL)) # 21908
length(unique(anot$SYMBOL)) # 20337

any(is.na(anot)==TRUE) #hay NA's
any(is.na(anot$ENSEMBL)==TRUE) #No hay NA's en ENSEMBL
any(is.na(anot$SYMBOL)==TRUE)  #los NA's estan en SYMBOL
anot <- anot[!is.na(anot$SYMBOL),] #quitar NA gene
dim(anot) # 20415 2

ex_anot <- merge(ex, anot, by = "ENSEMBL")
dim(ex_anot) # 20415    19
any(is.na(ex_anot)==TRUE) #no hay NA's
length(unique(ex_anot$SYMBOL)) # 20336

ex <- aggregate(ex_anot[,-c(1,19)],
                by=list(ex_anot$SYMBOL), max) #maximo con la suma por fila
dim(ex) # 20336    18
rownames(ex) <- ex[,1]
ex <- ex[,-c(1,12,13,14,15,16,18)] #GBM y control
dim(ex) # 20336    11

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Filtrado de genes --------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- ex[rowSums(ex)!=0,] #algunos genes no tienen expresion
dim(ex) # 19174 11

dim(ex[0<apply(ex,1,var),]) #todos los genes tienen variabilidad

#Reorganizando las columnas
genes <- rownames(ex)
ex <- data.frame(ex$GBM_3, ex$GBM_8, ex$GBM_9, ex$GBM_27, ex$GBM_29,
                 ex$control_6, ex$control_11, ex$control_12, 
                 ex$control_14, ex$control_15, ex$control_26)
colnames(ex) <- c("GBM1","GBM2","GBM3","GBM4","GBM5",
                  "C1","C2","C3","C4","C5","C6")
rownames(ex) <- genes

boxplot(ex,las=2,pch=20, cex=0.8)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Guardar y cargar datos finales -------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
# write.csv(ex,"23 datF_GSE159851.csv")
ex <- read.csv("23 datF_GSE159851.csv",row.names=1)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DESeq 2 ------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
coldata <- data.frame(condition=factor(c(rep('enf',5),rep('sano',6))))
rownames(coldata) <- colnames(ex)
coldata$condition <- relevel(coldata$condition, ref='enf')
coldata

dds0 <- DESeqDataSetFromMatrix(
  countData = ex,
  colData = coldata,
  design= ~ condition)

dds0 <- DESeq(dds0, test="LRT", reduced=~1) 
res0 <- results(dds0)
head(res0)

plotDispEsts(dds0, main="Conteos normalizados\n Media vs Dispersion")

resultsNames(dds0) # coeficientes
#una vez ajustado el modelo se aplica el m?todo de shrinkage
resLFC0 <- lfcShrink(dds0, coef="condition_sano_vs_enf", type="apeglm")
plotMA(resLFC0, main="Grafico MA")

Padj0 <- data.frame(p=res0$padj[res0$padj<0.95])
ggplot(Padj0, aes(x=p)) + geom_histogram(breaks = seq(0,0.95,0.05)) +
  labs(y='frecuencia') + scale_x_continuous(breaks = seq(0,0.95,0.05)) +
  geom_vline(xintercept=0.05, linetype="dashed", color = "red") +
  xlab("valor p ajustado") + ggtitle("Histograma para identificar\ncantidad de DEG's")

rld <- rlog(dds0, blind=FALSE) # transformacion log regularizado
boxplot(assay(rld),las=2,col=c(rep("red",5),rep("cyan",6)),
        pch=20, cex=0.8, main="Boxplots para muestras;\nConteos transformados")
corrplot(cor(assay(rld)),main="Correlaciones entre muestras")

resOrdered <- res0[order(res0$padj),]
resSig <- subset(res0, padj < 0.05)
resSig # 1618 DEGs

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs ---------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
DEGs <- rownames(resSig)
write(DEGs,"24 DEGs_GSE159851.txt")


# ##################################################################### # 
# --------------------------------------------------------------------- #
# FoldChange general -------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #

GenFinal <- c("PLK1", "CCNB1", "DLGAP5", "ESPL1", "NDC80", "BUB1B",
              "MYBL2", "TPX2", "E2F7", "KIF4A", "CDC45", "CCNA2", 
              "WEE1", "LMNA", "PDPN", "SKA1", "COL1A1", "COL4A2",
              "COL4A1", "PXDN", "LAMB1", "COL6A1", "BMP1", "VEGFA",
              "CHI3L1", "EGFLAM", "LIF", "ESM1", "TNFRSF12A", "CSPG4",
              "KIF11", "KIF20A", "KIF14", "LOXL2", "SHOX2", "SDC1",
              "NEBL", "LAMC1", "HS3ST4", "GCNT4", "CHPF2", "LFNG", 
              "ST6GALNAC1", "HOXA10", "HOXD10", "HOXA5")
GenFinal <- data.frame("Gen"=GenFinal)

foldChange <- data.frame(
  "Gen"=rownames(resSig),
  "F.c"=resSig$log2FoldChange
)

dplyr::inner_join(GenFinal, foldChange, by="Gen")

