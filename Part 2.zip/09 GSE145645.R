# ##################################################################### # 
# --------------------------------------------------------------------- #
# Carga de datos ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- read.table("10 FPKMlg2_GSE145645.txt", header=T)
ex1 <- ex[ex$Category=="protein_coding",-c(1,3)]
length(unique(ex1$Gene)) # 19774 genes 
exx <- aggregate(ex1[,-1],
                by=list(ex1$Gene), max)
genes <- exx$Group.1
ex <- exx[,-1]
rownames(ex) <- genes

pattern <- "/|:|\\?|<|>|\\|\\\\|\\*|-" # Quitando los caracteres especiales
ex <- ex[!grepl(pattern, rownames(ex)),]
dim(ex) # 19134 35
sum(substr(colnames(ex),1,3) == "GBM") # 32 GBM
sum(substr(colnames(ex),1,3) != "GBM") # 3 Normal brain Tissue

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Preprocesamiento ---------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
set.seed(56243)
MAS <- data.frame("GBM" = colnames(ex[,substr(colnames(ex),1,3) == "GBM"]),
                  "mas" = runif(32,0,1))
GBM <- ex[,substr(colnames(ex),1,3) == "GBM"]
ind <- order(MAS$mas)
GBM <- GBM[,ind]
masGBM <- GBM[,1:5] # 5 GBM con perdida esperada de 2 muestras
exMAS <- data.frame(masGBM,ex[,substr(colnames(ex),1,3) != "GBM"])
dim(exMAS) # 19134 8

boxplot(exMAS, las=2, col=c(rep("red",5),rep("cyan",3)))
corrplot(cor(exMAS))
plotDensities(exMAS, legend=F)

dd <- dist2(exMAS)
diag(dd) <- 0
dd.row <- as.dendrogram(hclust(as.dist(dd)))
row.ord <- order.dendrogram(dd.row)
legend <- list(top=list(fun=dendrogramGrob,args=list(x=dd.row,side="top")))
lp <- levelplot(dd[row.ord,row.ord],xlab="", ylab="",legend=legend, las=3,  labels=list(cex=0.2))
lp

meanSdPlot(as.matrix(exMAS), ranks=TRUE)

dim(exMAS) # 19134 8
ex <- exMAS[rowSums(exMAS)!=0,] #algunos genes no tienen expresion
dim(ex) # 17963 8
dim(ex[0<apply(ex,1,var),]) #todos los genes tienen variabilidad

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Normalizacion ------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex_norm <- justvsn(as.matrix(ex))

boxplot(ex_norm, las=2, col=c(rep("red",5),rep("cyan",3)))
corrplot(cor(ex_norm))
plotDensities(ex_norm, legend=F)

dd  <- dist2(ex_norm)
diag(dd) <- 0
dd.row <- as.dendrogram(hclust(as.dist(dd)))
row.ord <- order.dendrogram(dd.row)
legend <- list(top=list(fun=dendrogramGrob,args=list(x=dd.row,side="top")))
lp <- levelplot(dd[row.ord,row.ord],xlab="", ylab="",legend=legend, las=3,  labels=list(cex=0.2))
lp

meanSdPlot(ex_norm, ranks=TRUE)

# Trabajar sin normalizar ---------------------
ex_norm <- as.matrix(ex)
ex_norm <- ex_norm[0<apply(ex_norm,1,var),]
ex_norm <- ex_norm[,!colnames(ex_norm) %in% c("GBM01")]
dim(ex_norm) # 17963 7

boxplot(ex_norm, las=2, col=c(rep("red",4),rep("cyan",3)))
corrplot(cor(ex_norm))
plotDensities(ex_norm, legend=F)

dd  <- dist2(ex_norm)
diag(dd) <- 0
dd.row <- as.dendrogram(hclust(as.dist(dd)))
row.ord <- order.dendrogram(dd.row)
legend <- list(top=list(fun=dendrogramGrob,args=list(x=dd.row,side="top")))
lp <- levelplot(dd[row.ord,row.ord],xlab="", ylab="",legend=legend, las=3,  labels=list(cex=0.2))
lp

meanSdPlot(as.matrix(ex_norm), ranks=TRUE)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Guardar y cargar datos finales -------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
# write.csv(ex_norm,"11 datF_GSE145645.csv")
ex_norm <- read.csv("11 datF_GSE145645.csv",row.names=1)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# SAM ----------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
f <- c(rep(1,4),rep(0,3)) # 0 caso control, 1 caso enfermo
sam.out <- sam(ex_norm, f, rand = 123, gene.names = row.names(ex_norm))
sam.out

findDelta(sam.out, fdr = 0.05) #fijar fdr
sum.sam.out <- summary(sam.out, 1.586104)
sum.sam.out # 858 con un FDR 0.05

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs ---------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
write(rownames(sum.sam.out@mat.sig), "12 DEGs_GSE145645.txt")

