# ##################################################################### # 
# --------------------------------------------------------------------- #
# Carga de datos ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- read.table("06 fpkm_table_GSE119834.txt", header=T) 
# 45 GBM; 44 GSC; 9 NSC
ex <- ex[,substr(colnames(ex),1,3) != "GSC"]
dim(ex) #19471    55

length(unique(ex$symbol)) #19471 genes 
genes <- ex[,1]
rownames(ex) <- genes
ex <- ex[,-1]
ex <- cbind(ex[,substr(colnames(ex),1,3) == "GBM"],
            ex[,substr(colnames(ex),1,3) != "GBM"])
dim(ex)
length(colnames(ex[,substr(colnames(ex),1,3) == "GBM"]))
length(colnames(ex[,substr(colnames(ex),1,3) != "GBM"]))

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Preprocesamiento ---------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
set.seed(49241)
MAS <- data.frame("GBM" = colnames(ex[,substr(colnames(ex),1,3) == "GBM"]),
                  "mas" = runif(45,0,1))
GBM <- ex[,substr(colnames(ex),1,3) == "GBM"]
ind <- order(MAS$mas)
GBM <- GBM[,ind]
masGBM <- GBM[,1:11] # 11 GBM con perdida esperada de 2 muestras
exMAS <- data.frame(masGBM,ex[,substr(colnames(ex),1,3) != "GBM"])
dim(exMAS) # 19471 20

boxplot(exMAS, las=2)
corrplot(cor(exMAS))  
plotDensities(exMAS, legend=F)

dd <- dist2(exMAS)
diag(dd) <- 0
dd.row <- as.dendrogram(hclust(as.dist(dd)))
row.ord <- order.dendrogram(dd.row)
legend <- list(top=list(fun=dendrogramGrob,args=list(x=dd.row,side="top")))
lp <- levelplot(dd[row.ord,row.ord],xlab="", ylab="",legend=legend, las=2,  labels=list(cex=0.2))
lp

meanSdPlot(as.matrix(exMAS), ranks=TRUE)

exMAS <- exMAS[rowSums(exMAS)!=0,] # algunos genes no tienen expresion
dim(exMAS) # 19048 20

dim(exMAS[0<apply(exMAS,1,var),]) #todos los genes tienen variabilidad

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Normalizacion ------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex_norm <- justvsn(as.matrix(exMAS))
boxplot(ex_norm, las=2, col=c(rep("red",9),rep("cyan",9)))
corrplot(cor(ex_norm))

#nuevo filtro
ex_norm <- ex_norm[,!colnames(ex_norm) %in% c("GBM72","GBM32")]

boxplot(ex_norm, las=2, col=c(rep("red",9),rep("cyan",9)))
corrplot(cor(ex_norm))
plotDensities(ex_norm, legend=F)

dd  <- dist2(ex_norm)
diag(dd) <- 0
dd.row <- as.dendrogram(hclust(as.dist(dd)))
row.ord <- order.dendrogram(dd.row)
legend <- list(top=list(fun=dendrogramGrob,args=list(x=dd.row,side="top")))
lp <- levelplot(dd[row.ord,row.ord],xlab="", ylab="",legend=legend, las=3,  labels=list(cex=0.2))
lp

meanSdPlot(as.matrix(ex_norm), ranks=TRUE)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Guardar y cargar datos finales -------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
# write.csv(ex_norm,"07 datF_GSE119834.csv")
ex_norm <- read.csv("07 datF_GSE119834.csv",row.names=1)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# SAM ----------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
f <- c(rep(1,9),rep(0,9)) # 0 caso control, 1 caso enfermo
sam.out <- sam(ex_norm, f, rand = 123, gene.names = row.names(ex_norm))
sam.out 
findDelta(sam.out, fdr=0.0554)
sum.sam.out <- summary(sam.out,0.806160) #9778 DEGs
sum.sam.out

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs ---------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
write(rownames(sum.sam.out@mat.sig), "08 DEGs_GSE119834.txt")
