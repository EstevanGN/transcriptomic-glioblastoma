# ##################################################################### # 
# --------------------------------------------------------------------- #
# Librerias ----------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
library(infotheo)
library(affy)
library(siggenes)
library(minet)
library(igraph)
library(oligo)
library(RCy3)
library(viridis)
library(ricecdf)
library(dplyr)
library(ggplot2)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Cargar datos finales ------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- read.csv("datF.GSE147352.csv",row.names=1)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Filtro -------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
GenFinal <- c("PLK1", "CCNB1", "DLGAP5", "ESPL1", "NDC80", "BUB1B",
              "MYBL2", "TPX2", "E2F7", "KIF4A", "CDC45", "CCNA2", 
              "WEE1", "LMNA", "PDPN", "SKA1", "COL1A1", "COL4A2",
              "COL4A1", "PXDN", "LAMB1", "COL6A1", "BMP1", "VEGFA",
              "CHI3L1", "EGFLAM", "LIF", "ESM1", "TNFRSF12A", "CSPG4",
              "KIF11", "KIF20A", "KIF14", "LOXL2", "SHOX2", "SDC1",
              "NEBL", "LAMC1", "HS3ST4", "GCNT4", "CHPF2", "LFNG", 
              "ST6GALNAC1", "HOXA10", "HOXD10", "HOXA5")
DEGs <- ex[rownames(ex) %in% GenFinal,]

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Matriz de similitud ------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #

# Correlación lineal:
S <- abs(cor(t(DEGs), use="pairwise.complete.obs"))
dim(S)

hist(S,xlim=c(0,1),col=viridis(27), main="Histograma de S")

# Coeficiente de información mutua:
matplot(t(DEGs), type="l",xlab="Muestras",ylab="Nivel de expresión",las=1)
Ed <- discretize(t(DEGs), disc="globalequalwidth",nbins=ceiling(1+log(ncol(DEGs))))
matplot(Ed, type="l",xlab="Muestras",ylab="Nivel de expresión discretizado",las=1)

IM <- mutinformation(Ed,method= "shrink")
#Transformación para calcular el CIM en el intervalo [0,1]
S1<-sqrt(1-exp(-2*IM))
S1[which(is.na(S1))]<-0
hist(S1,xlim=c(0,1), col=viridis(27), main="Histograma de CIM")

# Utilizar coeficiente de correlacion lineal de pearson.

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Umbral -------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
n <- nrow(S)
tau <- seq(0.1,0.99,length=1000)
y <- NULL
for (j in 1:length(tau)){
  A=matrix(0,nrow=n,ncol=n)    
  
  #Completa la matriz de adyacencia usando la función de adyacencia:
  for(i in 1:n){  
    A[which(S[,i]>=tau[j]),i]<-1
    A[which(S[,i]<tau[j]),i]<-0
  }
  
  #Agrega nombres a filas y columnas
  colnames(A)<-rownames(A)<-rownames(DEGs)
  #Convierte la diagonal en ceros (red no dirigida):
  diag(A)<-0
  
  #Elimina nodos no conectados:
  A=A[rowSums(A)!=0,colSums(A)!=0]
  y[j] <- dim(A)[1]/n
}
data.frame(tau,"Percentil"=y) %>%
  ggplot( aes(x=tau, y=Percentil) ) + 
  geom_line(color="red") +
  annotate(geom="text", x=0.89, y=0.90, label=expression(tau==0.7842042)) +
  annotate(geom="point", x=0.7842042, y=0.90, size=3, shape=21,  fill="transparent")

tau[769]

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Matriz de adyacencia y red ------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
tao <- 0.7842042
A=matrix(0,nrow=n,ncol=n)
#Completa la matriz de adyacencia usando la función de adyacencia:
for(i in 1:n){
  A[which(S[,i]>=tao),i]<-1
  A[which(S[,i]<tao),i]<-0
}
#Agrega nombres a filas y columnas
colnames(A)<-rownames(A)<-rownames(DEGs)
#Convierte la diagonal en ceros (red no dirigida):
diag(A)<-0
#Elimina nodos no conectados:
A=A[rowSums(A)!=0,colSums(A)!=0]
# genes finales:
dim(A) #41   90% de los genes con anotación funcional
#Creamos la red
A=graph.adjacency(A,mode="undirected",add.colnames=NULL,diag=FALSE)
plot(A)
# mejorando grafico:
plot.igraph(A,layout=layout_with_kk,vertex.color = 'lightblue',
            vertex.size=2,edge.color="darkgreen",vertex.label.font=1,
            vertex.label.cex=0.6 )

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Cytoscape ----------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
createNetworkFromIgraph(A,"RedCoex")




