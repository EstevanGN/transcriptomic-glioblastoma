# ##################################################################### # 
# --------------------------------------------------------------------- #
# Carga de datos ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- read.csv("18 GSE151352_rsdsRlog.csv",header=T)
dim(ex)
colnames(ex)[1] <- "ENSEMBL"

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Simbolo de Gen ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
keytypes(org.Hs.eg.db)
cols <- c("SYMBOL")
ensids <- ex$ENSEMBL
anot <- select(org.Hs.eg.db, keys=ensids, columns=cols, keytype="ENSEMBL")

dim(anot) #58130   2
length(unique(anot$ENSEMBL)) #57905
length(unique(anot$SYMBOL)) #33246

any(is.na(anot)==TRUE) #hay NA's
any(is.na(anot$ENSEMBL)==TRUE) #No hay NA's en ENSEMBL
any(is.na(anot$SYMBOL)==TRUE)  #los NA's estan en SYMBOL
anot <- anot[!is.na(anot$SYMBOL),] #quitar NA gene
dim(anot) #33344     2

ex_anot <- merge(ex, anot, by = "ENSEMBL")
dim(ex_anot) #33344    26
any(is.na(ex_anot)==TRUE) #no hay NA's
length(unique(ex_anot$SYMBOL)) #33245

ex <- aggregate(ex_anot[,-c(1,26)],
                by=list(ex_anot$SYMBOL), max) #maximo con la suma por fila
dim(ex) #33245    25
rownames(ex) <- ex[,1]
ex <- ex[,-1]

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Filtrado de genes --------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- ex[rowSums(ex)!=0,] #algunos genes no tienen expresion
dim(ex) #20565    24

dim(ex[0<apply(ex,1,var),]) #todos los genes tienen variabilidad

#Reorganizando las columnas
genes <- rownames(ex)
ex <- data.frame(ex$X10T, ex$X16T, ex$X22T, ex$X25T, ex$X29T, ex$X39T,
                 ex$X42T, ex$X43T, ex$X45T, ex$X48T, ex$X49T, ex$X7T,
                 ex$X10N, ex$X16N, ex$X22N, ex$X25N, ex$X29N, ex$X39N,
                 ex$X42N, ex$X43N, ex$X45N, ex$X48N, ex$X49N, ex$X7N)
colnames(ex) <- substr(colnames(ex),4,9)
rownames(ex) <- genes

boxplot(ex,las=2,pch=20, cex=0.8, col=c(rep("red",12),rep("cyan",12)))
corrplot(cor(ex))

meanSdPlot(as.matrix(ex))

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Guardar y cargar datos finales -------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
# write.csv(ex,"19 datF_GSE151352.csv")
ex <- read.csv("19 datF_GSE151352.csv",row.names=1)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# SAM ----------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
f <- c(rep(1,12),rep(0,12)) # 0 caso control, 1 caso enfermo
sam.out <- sam(ex, f, rand = 123, gene.names = row.names(ex))
sam.out

findDelta(sam.out, fdr = 0.05) #fijar fdr
sum.sam.out <- summary(sam.out, 1.213711) 
sum.sam.out # 3517 DEGs

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs ---------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
DEGs <- rownames(sum.sam.out@mat.sig)
write(DEGs,"20 DEGs_GSE151352.txt")
