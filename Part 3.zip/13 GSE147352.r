# ##################################################################### # 
# --------------------------------------------------------------------- #
# Carga de datos ------------------------------------------------------ #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- data.frame(read.table("14 GSE147352/NB/NB1.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB2.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB3.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB4.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB5.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB6.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB7.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB8.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB9.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB10.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB11.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB12.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB13.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB14.txt",row.names=1),
                 read.table("14 GSE147352/NB/NB15.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM1.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM2.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM3.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM4.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM5.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM6.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM7.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM8.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM9.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM10.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM11.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM12.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM13.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM14.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM15.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM16.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM17.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM18.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM19.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM20.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM21.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM22.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM23.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM24.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM25.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM26.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM27.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM28.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM29.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM30.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM31.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM32.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM33.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM34.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM35.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM36.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM37.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM38.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM39.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM40.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM41.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM42.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM43.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM44.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM45.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM46.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM47.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM48.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM49.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM50.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM51.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM52.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM53.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM54.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM55.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM56.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM57.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM58.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM59.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM60.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM61.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM62.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM63.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM64.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM65.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM66.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM67.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM68.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM69.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM70.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM71.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM72.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM73.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM74.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM75.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM76.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM77.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM78.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM79.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM80.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM81.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM82.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM83.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM84.txt",row.names=1),
                 read.table("14 GSE147352/GBM/GBM85.txt",row.names=1))

x <- paste('NB', 1:15, sep='')
y <- paste('GBM', 1:85, sep='')
colnames(ex) <- c(x,y)

factor(sapply(ex, class)) #Todos son clase enteros

dim(ex)  # 58307 100
ex <- cbind("ENSEMBL"=rownames(ex), ex)
rownames(ex) <- c()

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Simbolo Gen --------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
keytypes(org.Hs.eg.db)
cols <- c("SYMBOL")
ensids <- ex$ENSEMBL
anot <- select(org.Hs.eg.db, keys=ensids, columns=cols, keytype="ENSEMBL")

dim(anot) # 58547 2
length(unique(anot$ENSEMBL)) # 58307
length(unique(anot$SYMBOL))  # 35150

any(is.na(anot)==TRUE) #hay NA's
any(is.na(anot$ENSEMBL)==TRUE) #No hay NA's en ENSEMBL
any(is.na(anot$SYMBOL)==TRUE)  #los NA's estan en SYMBOL
anot <- anot[!is.na(anot$SYMBOL),] #quitar NA gene
dim(anot) # 35273 2

ex_anot <- merge(ex, anot, by = "ENSEMBL")
dim(ex_anot) # 35273 102
any(is.na(ex_anot)==TRUE) #no hay NA's
length(unique(ex_anot$SYMBOL)) # 35149

ex <- aggregate(ex_anot[,-c(1,102)],
                by=list(ex_anot$SYMBOL), max) #maximo con la suma por fila
dim(ex) # 35149 101
rownames(ex) <- ex[,1]
ex <- ex[,-1]
dim(ex) # 35149 100

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Filtrado de genes --------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
ex <- ex[rowSums(ex)!=0,] #algunos genes no tienen expresion
dim(ex) # 32661 100

dim(ex[0<apply(ex,1,var),]) #todos los genes tienen variabilidad

#reorganizando columnas
ex <- cbind(ex[,16:100],ex[,1:15])
colnames(ex)

# MAS
set.seed(49241)
MAS <- data.frame("GBM" = colnames(ex[,substr(colnames(ex),1,3) == "GBM"]),
                  "mas" = runif(85,0,1))
GBM <- ex[,substr(colnames(ex),1,3) == "GBM"]
ind <- order(MAS$mas)
GBM <- GBM[,ind]
masGBM <- GBM[,1:17] # 17 GBM con perdida esperada de 2 muestras
exMAS <- data.frame(masGBM,ex[,substr(colnames(ex),1,3) != "GBM"])
dim(exMAS) # 32661 32

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DESeq 2 ------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
coldata <- data.frame(condition=factor(c(rep('enf',17),rep('sano',15))))
rownames(coldata) <- colnames(exMAS)
coldata$condition <- relevel(coldata$condition, ref='enf')
coldata

dds0 <- DESeqDataSetFromMatrix(
  countData = exMAS,
  colData = coldata,
  design= ~ condition)

dds0 <- DESeq(dds0, test="LRT", reduced=~1) 
res0 <- results(dds0)
head(res0)

plotDispEsts(dds0, main="Conteos normalizados\n Media vs Dispersion")

resultsNames(dds0) # coeficientes
#una vez ajustado el modelo se aplica el m?todo de shrinkage
resLFC0 <- lfcShrink(dds0, coef="condition_sano_vs_enf", type="apeglm")
plotMA(resLFC0, main="Grafico MA")

Padj0 <- data.frame(p=res0$padj[res0$padj<0.95])
ggplot(Padj0, aes(x=p)) + geom_histogram(breaks = seq(0,0.95,0.05)) +
  labs(y='frecuencia') + scale_x_continuous(breaks = seq(0,0.95,0.05)) +
  geom_vline(xintercept=0.05, linetype="dashed", color = "red") +
  xlab("valor p ajustado") + ggtitle("Histograma para identificar\ncantidad de DEG's")

resOrdered <- res0[order(res0$padj),]
resSig <- subset(res0, padj < 0.05)
resSig # 15059 DEGs

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Estadistica descriptiva --------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
rld <- rlog(dds0, blind=FALSE) # transformación log regularizado
boxplot(assay(rld),las=2,col=c(rep("red",17),rep("cyan",15)),
        pch=20, cex=0.8, main="Boxplots para muestras\nconteos transformados")
corrplot(cor(assay(rld)))

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Guardar y cargar datos finales -------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
# write.csv(exMAS,"15 datF_GSE147352.csv")
ex <- read.csv("15 datF_GSE147352.csv",row.names=1)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DESeq 2 ------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
coldata <- data.frame(condition=factor(c(rep('enf',17),rep('sano',15))))
rownames(coldata) <- colnames(ex)
coldata$condition <- relevel(coldata$condition, ref='enf')
coldata

dds0 <- DESeqDataSetFromMatrix(
  countData = ex,
  colData = coldata,
  design= ~ condition)

dds0 <- DESeq(dds0, test="LRT", reduced=~1) 
res0 <- results(dds0)
head(res0)

plotDispEsts(dds0, main="Conteos normalizados\n Media vs Dispersion",
             xlab="Media de conteos normalizados", 
             ylab="dispersion")

resultsNames(dds0) # coeficientes
#una vez ajustado el modelo se aplica el m?todo de shrinkage
resLFC0 <- lfcShrink(dds0, coef="condition_sano_vs_enf", type="apeglm")
plotMA(resLFC0, main="Grafico MA",xlab="Media de conteos normalizados")

Padj0 <- data.frame(p=res0$padj[res0$padj<0.95])
ggplot(Padj0, aes(x=p)) + geom_histogram(breaks = seq(0,0.95,0.05)) +
  labs(y='frecuencia') + scale_x_continuous(breaks = seq(0,0.95,0.05)) +
  geom_vline(xintercept=0.05, linetype="dashed", color = "red") +
  xlab("valor p ajustado") + ggtitle("Histograma para identificar\ncantidad de DEG's")

resOrdered <- res0[order(res0$padj),]
resSig <- subset(res0, padj < 0.05)
resSig # 15059

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Estadistica descriptiva --------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
rld <- rlog(dds0, blind=FALSE) # transformacion log regularizado
boxplot(assay(rld),las=2,col=c(rep("red",17),rep("cyan",15)),
        pch=20, cex=0.8, main="Boxplots para muestras\nconteos transformados")
corrplot(cor(assay(rld)))

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs ---------------------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
DEGs <- rownames(resSig)
write(DEGs,"16 DEGs_GSE147352.txt")
