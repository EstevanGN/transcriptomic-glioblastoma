# Cualquier metodo de obtencion para DEGs -------------------------------------

# Leer los DEGs comunes a los 5 conjuntos de datos
DEGs <- read.table("27 DEGs_todos_conjuntos.txt")

# Leer la tabla de datos de algún GSE
# -----------------------------------

# Dividiendo los grupos
case <- which(str_detect(names(ex), "GBM", negate = FALSE), TRUE)
control <- which(str_detect(names(ex), "GBM", negate = TRUE), TRUE)

avg.GBM <- apply((ex[,case]), 1, mean)
avg.NSC <- apply((ex[,control]), 1, mean)
fc <- avg.GBM/avg.NSC
logFC <- data.frame( "log2FC" = log2(fc) )

ind <- rownames(logFC) %in% DEGs[,1]
sum(ind)

final <- data.frame("Genes"=names(fc[ind]), "FC"=fc[ind])
rownames(final) <- c()
write_csv(final, "temp.csv")
