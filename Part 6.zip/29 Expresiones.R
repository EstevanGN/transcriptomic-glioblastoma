genes <- c("PLK1","CCNB1","DLGAP5","ESPL1","NDC80","BUB1B","MYBL2",
           "TPX2","E2F7","KIF4A","CDC45","CCNA2","WEE1","LMNA","PDPN",
           "SKA1","COL1A1","COL4A2","COL4A1","PXDN","LAMB1","COL6A1",
           "BMP1","VEGFA","CHI3L1","EGFLAM","LIF","ESM1","TNFRSF12A",
           "CSPG4","KIF11","KIF20A","KIF14","LOXL2","SHOX2","SDC1","NEBL",
           "LAMC1","HS3ST4","GCNT4","CHPF2","LFNG","ST6GALNAC1","HOXA10",
           "HOXD10","HOXA5","IDH1","IDH2")

expre <-  data.frame( "Muestra"=colnames(ex),
                      t(ex[rownames(ex) %in% genes,])
                      )


write_csv(expre, "temp.csv")
