GSE119834 <- read.table("08 DEGs_GSE119834.txt", header = FALSE)
GSE145645 <- read.table("12 DEGs_GSE145645.txt", header = FALSE)
GSE147352 <- read.table("16 DEGs_GSE147352.txt", header = FALSE)
GSE151352 <- read.table("20 DEGs_GSE151352.txt", header = FALSE)
GSE159851 <- read.table("24 DEGs_GSE159851.txt", header = FALSE)

problem <- c("PDPN",
             "COL1A1",
             "COL6A1",
             "VEGFA",
             "EGFLAM",
             "CSPG4",
             "SHOX2")
problem %in% GSE119834
problem %in% GSE145645
problem %in% GSE147352
problem %in% GSE151352
problem %in% GSE159851


ex_norm <- read.csv("07 datF_GSE119834.csv",row.names=1)
f <- c(rep(1,10),rep(0,9)) # 0 caso control, 1 caso enfermo
GSE1 <- sam(ex_norm, f, rand = 123, gene.names = row.names(ex_norm))
ind <- c(
  which(names(sam.out@p.value) == problem[1]),
  which(names(sam.out@p.value) == problem[2]),
  which(names(sam.out@p.value) == problem[3]),
  which(names(sam.out@p.value) == problem[4]),
  which(names(sam.out@p.value) == problem[5]),
  which(names(sam.out@p.value) == problem[6]),
  which(names(sam.out@p.value) == problem[7])
)
GSE1@p.value[ind]

