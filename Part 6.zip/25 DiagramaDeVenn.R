# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs por cada conjunto de datos ------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
GSE119834 <- read.table("08 DEGs_GSE119834.txt",sep = ",")[,1]
GSE145645 <- read.table("12 DEGs_GSE145645.txt",sep = ",")[,1]
GSE147352 <- read.table("16 DEGs_GSE147352.txt",sep = ",")[,1]
GSE151352 <- read.table("20 DEGs_GSE151352.txt",sep = ",")[,1]
GSE159851 <- read.table("24 DEGs_GSE159851.txt",sep = ",")[,1]

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Diagrama de Venn ---------------------------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
venn.diagram(
  x = list(
    GSE119834, 
    GSE145645,
    GSE147352,
    GSE151352,
    GSE159851),
  category.names = c("GSE119834",
                     "GSE145645",
                     "GSE147352",
                     "GSE151352",
                     "GSE159851"),
  filename = '26 CompleteDEGsVenn.png',
  output = TRUE,
  imagetype= "png",
  height = 1080, 
  width = 1080, 
  resolution = 600,
  compression = "lzw",
  lwd = 1,
  cex = 0.4,
  col=c("#FB8B24",
        "#D90368",
        "#820263",
        "#291720",
        "#04A777"),
  fill = c(alpha("#FB8B24",0.3),
           alpha("#D90368",0.3),
           alpha("#820263",0.3),
           alpha("#291720",0.3),
           alpha("#04A777",0.3)),
  fontfamily = "sans",
  cat.cex = 0.3,
  cat.default.pos = "outer",
  cat.pos = c(-27, 27, 135, -135, 180),
  cat.dist = c(0.055, 0.055, 0.085, 0.085, 0.055),
  cat.fontfamily = "sans",
  cat.col = c("#FB8B24",
              "#D90368",
              "#820263",
              "#291720",
              "#04A777")
)

# ##################################################################### # 
# --------------------------------------------------------------------- #
# DEGs comunes en todos los conjuntos --------------------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #
v.table <- venn(list(GSE119834, 
                     GSE145645,
                     GSE147352,
                     GSE151352,
                     GSE159851))
print(v.table)

# guardar DEGs comunes a todos los conjuntos de datos
todos <- attr(v.table,"intersections")$`A:B:C:D:E`
write(todos, "27 DEGs_todos_conjuntos.txt")

# ##################################################################### # 
# --------------------------------------------------------------------- #
# Guardar DEGs comunes con el experimento estrella -------------------- #
# --------------------------------------------------------------------- #
# ##################################################################### #

## GSE151352
#ggVennDiagram(list(GSE147352,GSE151352), label_alpha = 0,
#              category.names = c("GSE147352\nA",
#                                 "GSE151352\nB"),
#              set_size=2.1, label_size=3.2)
#print(venn(list(GSE147352,GSE151352)))
#c1 <- attr(venn(list(GSE147352,GSE151352)),"intersections")$`A:B`
#write(c1, "GSE151352_comparacion.txt")
#
## GSE119834
#ggVennDiagram(list(GSE147352,GSE119834), label_alpha = 0,
#              category.names = c("GSE147352\nA",
#                                 "GSE119834\nB"),
#              set_size=2.1, label_size=3.2)
#print(venn(list(GSE147352,GSE119834)))
#c2 <- attr(venn(list(GSE147352,GSE119834)),"intersections")$`A:B`
#write(c2, "GSE119834_comparacion.txt")
#
## GSE159851
#ggVennDiagram(list(GSE147352,GSE159851), label_alpha = 0,
#              category.names = c("GSE147352\nA",
#                                 "GSE159851\nB"),
#              set_size=2.1, label_size=3.2)
#print(venn(list(GSE147352,GSE159851)))
#c3 <- attr(venn(list(GSE147352,GSE159851)),"intersections")$`A:B`
#write(c3, "GSE159851_comparacion.txt")
#
## GSE145645
#ggVennDiagram(list(GSE147352,GSE145645), label_alpha = 0,
#              category.names = c("GSE147352\nA",
#                                 "GSE145645\nB"),
#              set_size=2.1, label_size=3.2)
#print(venn(list(GSE147352,GSE145645)))
#c4 <- attr(venn(list(GSE147352,GSE145645)),"intersections")$`A:B`
#write(c4, "GSE145645_comparacion.txt")
#